package ut;

import android.util.Log;
import android.view.View;

/**
 * @作者 做就行了！
 * @时间 2019/4/17 0017
 * @使用说明：
 */
public class LogUT {
    public static void logXYWH(View view, String prefix){
        Log.e("TAG", prefix+":" +
                " x = " + view.getX() +
                ", y = " + view.getY() +
                ", width = " + view.getWidth() +
                ", height = " + view.getHeight() +
                " 。");
    }
}

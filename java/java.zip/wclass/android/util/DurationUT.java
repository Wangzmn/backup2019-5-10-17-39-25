package wclass.android.util;

/**
 * @作者 做就行了！
 * @时间 2019-02-04上午 12:50
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class DurationUT {
    public static final long CLICK_LIMIT_TIME = 300;
    public static final long LONG_CLICK_NEED_TIME = 2000;
    public static final long ANIM_DURATION = 200;
}

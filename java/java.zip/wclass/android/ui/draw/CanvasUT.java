package wclass.android.ui.draw;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

/**
 * @作者 做就行了！
 * @时间 2019/3/17 0017
 * @使用说明：
 */
public class CanvasUT {
    /**
     * todo
     * 1、绘制矩形内阴影。
     * 2、绘制矩形外阴影。
     */
//    public static void draw(Canvas canvas, Rect rect,Paint paint
//    ,)
}

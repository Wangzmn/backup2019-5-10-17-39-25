package wclass.android.ui.view.tab_layout;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import wclass.android.ui.view.rover_view.MoverView;
import wclass.enums.Orien2;
import wclass.enums.Where2;
import wclass.util.ColorUT;

/**
 * @作者 做就行了！
 * @时间 2019/4/3 0003
 * @使用说明：
 */
public abstract class TabLayoutHori<T extends View> extends TabLayout<T> {

    private static final boolean DEBUG = true;
    /**
     * 作为indicator的容器。
     */
    MoverView moverView;
    private final Context context;//上下文。
    private final int tabCount;//tab的数量。
    //--------------------------------------------------
    /**
     * 用户没设置indicator占位大小时，使用该值作为最大的大小。
     */
    private final int holderSizeRefer;
    /**
     * indicator所在容器的布局rect。
     */
    Rect freeViewRect = new Rect();
    /**
     * indicator占位大小。
     * -1为使用默认值。
     */
    int mIndicatorHolderSize = -1;
    //    Drawable mIndicatorDrawable;
    /**
     * todo 待扩展。
     * 指示器放在之前还是之后。
     */
    private Where2 mIndicatorLocation = Where2.AFTER;
    //////////////////////////////////////////////////

    public TabLayoutHori(Context context, int tabCount) {
        super(context, tabCount);
        moverView = new MoverView(context);
        this.context = context;
        this.tabCount = tabCount;
//        holderSizeRefer = SizeUT.getMMpixel(context) / 2;
        holderSizeRefer = 20;
        addView(moverView);
        freeDrawableRect = moverView.getMoverRect();
        if (DEBUG) {
            moverView.setBackgroundColor(ColorUT.BLUE);
            moverView.setMoverDrawable(new ColorDrawable(ColorUT.RED));
        }
    }
    //////////////////////////////////////////////////

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        //--------------------------------------------------
        moverView.measure(getMeasuredWidthAndState(), getMeasuredHeightAndState());
        moverView.layout(0, 0, freeViewRect.width(), freeViewRect.height());
        moverView.setX(freeViewRect.left);
        moverView.setY(freeViewRect.top);
        //--------------------------------------------------

        TabInfo selectedTab = getSelectedTab();
        switch (getOrien()) {
            case HORIZONTAL:
                freeDrawableRect.top = moverView.getPaddingTop();
                freeDrawableRect.bottom = freeDrawableRect.top
                        + moverView.getHeight()
                        - moverView.getPaddingBottom();
                freeDrawableRect.left = selectedTab.rect.left;
                freeDrawableRect.right = selectedTab.rect.right;

                recordIndicatorRect.set(freeDrawableRect);

                moverView.reRect(freeDrawableRect);
                break;
            case VERTICAL:
                break;
            default:
                throw new IllegalStateException();
        }
    }

    Rect recordIndicatorRect = new Rect();

    @Override
    protected void onLayoutFinish() {
        super.onLayoutFinish();

    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        Log.e("TAG", " freeViewRect = " + freeViewRect);
        Log.e("TAG", " freeDrawableRect = " + freeDrawableRect);
        return super.dispatchTouchEvent(ev);
    }

    //////////////////////////////////////////////////
    /*indicator动画相关*/
    @Override
    protected void onSelectedChanged(TabInfo newTab, TabInfo oldTab, boolean fromTouch) {
        super.onSelectedChanged(newTab, oldTab, fromTouch);
        if (mIndicatorHolderSize == 0) {
            return;
        }
        Rect rect = newTab.rect;
        switch (getOrien()) {
            case HORIZONTAL:
                moverView.animReHori(rect.left, rect.right);
                break;
            case VERTICAL:
                break;
                default:
                throw new IllegalStateException();
        }
    }

    //--------------------------------------------------
    Rect freeDrawableRect;

    /**
     * 调整indicator的占位大小。
     *
     * @param pendingUsableRect 待调整的tabLayout的可使用区域。
     * @param l                 tabLayout在父容器中的left。
     * @param t                 tabLayout在父容器中的top。
     * @param r                 tabLayout在父容器中的right。
     * @param b                 tabLayout在父容器中的bottom。
     */
    @Override
    protected void onAdjustUsableRect(Rect pendingUsableRect, int l, int t, int r, int b) {
        super.onAdjustUsableRect(pendingUsableRect, l, t, r, b);
        if (pendingUsableRect.isEmpty() || mIndicatorHolderSize == 0) {
            return;
        }
        switch (getOrien()) {
            case HORIZONTAL:
                int holderSize;
                int height = pendingUsableRect.height();
                //使用默认值。
                if (mIndicatorHolderSize <= 0) {
                    holderSize = Math.min(height, holderSizeRefer);
                }
                //使用用户设置的值。
                else {
                    holderSize = Math.min(height, mIndicatorHolderSize);
                }

                pendingUsableRect.bottom -= holderSize;

                freeViewRect.left = pendingUsableRect.left;
                freeViewRect.right = pendingUsableRect.right;
                freeViewRect.top = pendingUsableRect.bottom;
                freeViewRect.bottom = freeViewRect.top + holderSize;

                break;
            case VERTICAL:
                int holderSize2;
                int width = pendingUsableRect.width();
                //使用默认值。
                if (mIndicatorHolderSize <= 0) {
                    holderSize2 = Math.min(width, holderSizeRefer);
                }
                //使用用户设置的值。
                else {
                    holderSize2 = Math.min(width, mIndicatorHolderSize);
                }
                pendingUsableRect.right -= holderSize2;
                freeViewRect.top = pendingUsableRect.top;
                freeViewRect.bottom = pendingUsableRect.bottom;
                freeViewRect.left = pendingUsableRect.right;
                freeViewRect.right = freeViewRect.left + holderSize2;
                break;
            default:
                throw new IllegalStateException();
        }
    }

    @Override
    protected TabRectMaker onCreateDefaultTabXYMaker() {
        return new TabRectMaker() {
            @Override
            public void make(Rect pendingTabRect, Rect rootUsableRect, TabLayout tabLayout, Orien2 rootOrien, int[] tabWidthHeight, int tabDex) {
                switch (rootOrien) {
                    case HORIZONTAL:
                        int tabWidth = tabWidthHeight[0];
                        pendingTabRect.left = tabDex * tabWidth;
                        pendingTabRect.top = rootUsableRect.top;
                        pendingTabRect.right = pendingTabRect.left + tabWidth;
                        pendingTabRect.bottom = pendingTabRect.top + tabWidthHeight[1];
                        break;
                    case VERTICAL:
                        break;
                }
            }
        };
    }

    @Override
    protected TabSizeMaker onCreateDefaultTabSizeMaker() {
        return new TabSizeMaker() {
            @Override
            public void make(int[] pendingTabWidthHeight, TabLayout tabLayout, Orien2 orien, Rect rootUsableRect, int tabCount) {
                switch (orien) {
                    case HORIZONTAL:
                        pendingTabWidthHeight[0] = rootUsableRect.width() / tabCount;
                        pendingTabWidthHeight[1] = rootUsableRect.height();
                        break;
                    case VERTICAL:
                        break;
                }
            }
        };
    }

    //////////////////////////////////////////////////
    /*todo */
    public void setIndicatorDrawable(Drawable indicatorDrawable) {
//        mIndicatorDrawable = indicatorDrawable;
        moverView.setMoverDrawable(indicatorDrawable);
    }

    /**
     * 设置indicator占位大小。
     *
     * @param indicatorHolderSize indicator占位大小。
     */
    public void setIndicatorHolderSize(int indicatorHolderSize) {
        mIndicatorHolderSize = indicatorHolderSize;
    }
}

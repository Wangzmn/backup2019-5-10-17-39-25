package wclass.android.ui.view.free_drawable_view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;

import wclass.android.util.AnimatorUT;

/**
 * @作者 做就行了！
 * @时间 2019-04-03下午 2:50
 * @该类描述： -
 * 1、滑动指示器。
 * 长条状控件，一个图片在该控件上滑动。
 * 2、通过动画移动图片方法：
 * {@link #animReHori}{@link #animReVerti}；
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class FreeDrawableView extends View {
    private static final boolean DEBUG = true;
    /**
     * freeDrawable的rect。
     */
    Rect drawableRect = new Rect();
    /**
     * 可以调整rect的drawable。
     */
    private Drawable freeDrawable;

    //////////////////////////////////////////////////
    public FreeDrawableView(Context context) {
        super(context);
    }
    //////////////////////////////////////////////////

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (drawableRect.isEmpty()) {
            getDrawingRect(drawableRect);
            drawableRect.left += getPaddingLeft();
            drawableRect.top += getPaddingTop();
            drawableRect.right -= getPaddingRight();
            drawableRect.bottom -= getPaddingBottom();
            setFreeBoundsOptimize();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        preDrawFreeDrawable(canvas);
        if (freeDrawable != null) {
            onDrawFreeDrawable(canvas, freeDrawable);
        }
    }

    /**
     * 该方法中绘制freeDrawable。
     */
    protected void onDrawFreeDrawable(Canvas canvas, Drawable freeDrawable) {
        freeDrawable.draw(canvas);
        if (DEBUG) {
            Log.e("TAG", " wclass.android.ui.view.free_drawable_view.FreeDrawableView.onDrawFreeDrawable ");
        }
    }

    /**
     * 绘制freeDrawable之前，该方法被调用。
     */
    protected void preDrawFreeDrawable(Canvas canvas) {

    }

    //--------------------------------------------------

    /**
     * 设置freeDrawable的rect，并刷新显示。
     */
    private void setFreeBoundsOptimize() {
        if (freeDrawable != null) {
            cleanAnim();
            freeDrawable.setBounds(drawableRect);
            invalidate();
        }
    }

    //////////////////////////////////////////////////
    /*动画相关。*/
    /**
     * 操作freeDrawable rect的动画对象。
     */
    private ValueAnimator valueAnimator;

    /**
     * 清除动画。
     */
    private void cleanAnim() {
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
    }

    /**
     * {@link FreeDrawableView#animReHori(int, int, long)}
     */
    public void animReHori(int dstLeft, int dstRight) {
        animReHori(dstLeft, dstRight, 200);
    }

    /**
     * 动画改变freeDrawable rect的横向属性。
     *
     * @param dstLeft  目标left。
     * @param dstRight 目标right。
     * @param duration 动画持续时间。
     */
    public void animReHori(int dstLeft, int dstRight, long duration) {

        int startLeft = drawableRect.left;
        int startRight = drawableRect.right;
        int leftCut = dstLeft - startLeft;
        int rightCut = dstRight - startRight;
        valueAnimator = AnimatorUT.forProgressPercentage(duration, new AnimatorUT.Update() {
            @Override
            public void onUpdate(float progress) {
                int currLeft = (int) (startLeft + progress * leftCut + 0.5f);
                int currRight = (int) (startRight + progress * rightCut + 0.5f);
                drawableRect.left = currLeft;
                drawableRect.right = currRight;
                freeDrawable.setBounds(drawableRect);
                invalidate();
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onEnd() {
                valueAnimator = null;
            }

            @Override
            public void onCancel() {
                valueAnimator = null;
            }
        });
    }

    /**
     * {@link FreeDrawableView#animReVerti(int, int, long)}
     */
    public void animReVerti(int dstTop, int dstBottom) {
        animReVerti(dstTop, dstBottom, 200);
    }

    /**
     * 动画改变freeDrawable rect的纵向属性。
     *
     * @param dstTop    目标top。
     * @param dstBottom 目标bottom。
     * @param duration  动画持续时间。
     */
    public void animReVerti(int dstTop, int dstBottom, long duration) {
        int startTop = drawableRect.top;
        int startBottom = drawableRect.bottom;
        int topCut = dstTop - startTop;
        int bottomCut = dstBottom - startBottom;
        valueAnimator = AnimatorUT.forProgressPercentage(duration, new AnimatorUT.Update() {
            @Override
            public void onUpdate(float progress) {
                int currTop = (int) (startTop + progress * topCut + 0.5f);
                int currBottom = (int) (startBottom + progress * bottomCut + 0.5f);
                drawableRect.top = currTop;
                drawableRect.bottom = currBottom;
                freeDrawable.setBounds(drawableRect);
                invalidate();
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onEnd() {
                valueAnimator = null;
            }

            @Override
            public void onCancel() {
                valueAnimator = null;
            }
        });
    }

    //////////////////////////////////////////////////

    /**
     * 获取freeDrawable。
     */
    public Drawable getFreeDrawable() {
        return freeDrawable;
    }

    /**
     * 获取freeDrawable的rect。
     */
    public Rect getFreeRect() {
        return drawableRect;
    }

    /**
     * 获取freeDrawable的rect的left。
     */
    public int left() {
        return drawableRect.left;
    }

    /**
     * 获取freeDrawable的rect的top。
     */
    public int top() {
        return drawableRect.top;
    }

    /**
     * 获取freeDrawable的rect的right。
     */
    public int right() {
        return drawableRect.right;
    }

    /**
     * 获取freeDrawable的rect的bottom。
     */
    public int bottom() {
        return drawableRect.bottom;
    }
    //--------------------------------------------------
    /*设置相关。*/

    /**
     * 设置freeDrawable的图片。
     *
     * @param drawable 图片。
     */
    public void setFreeDrawable(Drawable drawable) {
        this.freeDrawable = drawable;
    }


    /**
     * 重新调整freeDrawable的rect。
     */
    public void reRect(Rect rect) {
        drawableRect = rect;
        setFreeBoundsOptimize();
    }


    /**
     * 重新调整freeDrawable rect的left属性。
     * <p>
     * 调用完请必须调用{@link FreeDrawableView#apply()}刷新。
     *
     * @param left 设置rect的left。
     * @return this
     */
    public FreeDrawableView reLeft(int left) {
        drawableRect.left = left;
        return this;
    }


    /**
     * 重新调整freeDrawable rect的top属性。
     * <p>
     * 调用完请必须调用{@link FreeDrawableView#apply()}刷新。
     *
     * @param top 设置rect的top。
     * @return this
     */
    public FreeDrawableView reTop(int top) {
        drawableRect.top = top;
        return this;
    }


    /**
     * 重新调整freeDrawable rect的right属性。
     * <p>
     * 调用完请必须调用{@link FreeDrawableView#apply()}刷新。
     *
     * @param right 设置rect的right。
     * @return this
     */
    public FreeDrawableView reRight(int right) {
        drawableRect.right = right;
        return this;
    }

    /**
     * 重新调整freeDrawable rect的bottom属性。
     * <p>
     * 调用完请必须调用{@link FreeDrawableView#apply()}刷新。
     *
     * @param bottom 设置rect的bottom。
     * @return this
     */
    public FreeDrawableView reBottom(int bottom) {
        drawableRect.bottom = bottom;
        return this;
    }

    /**
     * 重新调整横向的绘制区域。
     *
     * @param left  freeDrawable rect的left属性。
     * @param right freeDrawable rect的right属性。
     */
    public void reHori(int left, int right) {
        drawableRect.left = left;
        drawableRect.right = right;
        apply();
    }

    /**
     * 重新调整纵向的绘制区域。
     *
     * @param top    freeDrawable rect的top属性。
     * @param bottom freeDrawable rect的bottom属性。
     */
    public void reVerti(int top, int bottom) {
        drawableRect.top = top;
        drawableRect.bottom = bottom;
        apply();
    }

    /**
     * 应用freeDrawable的rect。
     */
    public void apply() {
        setFreeBoundsOptimize();
    }

}

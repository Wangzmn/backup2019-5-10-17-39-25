package wclass.android.ui.view.rover_view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;

import wclass.android.base_view.BaseCustomView;
import wclass.android.util.AnimatorUT;

/**
 * @作者 做就行了！
 * @时间 2019-04-03下午 2:50
 * @该类描述： -
 * 1、一个图片可以显示在view中的任何位置。
 * 2、通过动画改变图片位置的方法：
 * {@link #animReHori}{@link #animReVerti}。
 * （其实还可以直接进行rect整体变化的，我先不写了。）
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 * todo
 * 1、动画时设置bounds写在draw方法中，动画中只做标记作用。
 */
public class RoverView extends BaseCustomView {
    private static final boolean DEBUG = true;
    /**
     * 漫游图片的rect。
     */
    Rect roverRect = new Rect();
    /**
     * 漫游的图片。
     */
    private Drawable roverDrawable;
    private boolean needReRect =true;

    //////////////////////////////////////////////////
    public RoverView(Context context) {
        super(context);
    }
    //////////////////////////////////////////////////

    /**
     * fix 这个方法有问题！！！
     * <p>
     * todo
     * 1、这个方法写在onDraw中怎么样？？？
     */
    protected void onCalculateRoverRect(Rect roverRect) {
        if (needReRect) {
            roverDrawable.setBounds(roverRect);
        }
//        //todo 待废弃。
//        if (roverRect.isEmpty()) {
//            getDrawingRect(roverRect);
//            roverRect.left += getPaddingLeft();
//            roverRect.top += getPaddingTop();
//            roverRect.right -= getPaddingRight();
//            roverRect.bottom -= getPaddingBottom();
//            int width = roverRect.width();
//            int height = roverRect.height();
//            //默认绘制在左上角。
//            roverRect.right -= width / 2;
//            roverRect.bottom -= height / 2;
//            setRoverBoundsOptimize();
//        }
    }

    protected void onCalculateAllDrawing(boolean changed) {
        onCalculateRoverRect(roverRect);
    }

    @Override
    protected void onDrawAll(Canvas canvas) {
        super.onDrawAll(canvas);
        if (roverDrawable != null) {
            preDrawRover(canvas);
            onDrawRover(canvas, roverDrawable);
        }
    }

    /**
     * 该方法中绘制roverDrawable。
     */
    protected void onDrawRover(Canvas canvas, Drawable roverDrawable) {
        if (DEBUG) {
            Log.e("TAG", getClass() + "#onDrawRover");
        }
        roverDrawable.draw(canvas);
    }

    /**
     * 绘制roverDrawable之前，该方法被调用。
     */
    protected void preDrawRover(Canvas canvas) {

    }

    //--------------------------------------------------

    /**
     * 设置roverDrawable的rect，并刷新显示。
     */
    private void setRoverBoundsOptimize() {
        if (roverDrawable != null) {
            cleanAnim();
            needReRect=true;
            invalidate();
        }
    }

    //////////////////////////////////////////////////
    /*动画相关。*/
    /**
     * 操作roverDrawable rect的动画对象。
     */
    private ValueAnimator valueAnimator;

    /**
     * 清除动画。
     */
    private void cleanAnim() {
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
    }

    /**
     * {@link RoverView#animReHori(int, int, long)}
     */
    public void animReHori(int dstLeft, int dstRight) {
        animReHori(dstLeft, dstRight, 200);
    }

    /**
     * 动画改变roverDrawable rect的横向属性。
     *
     * @param dstLeft  目标left。
     * @param dstRight 目标right。
     * @param duration 动画持续时间。
     */
    public void animReHori(int dstLeft, int dstRight, long duration) {

        int startLeft = roverRect.left;
        int startRight = roverRect.right;
        int leftCut = dstLeft - startLeft;
        int rightCut = dstRight - startRight;
        valueAnimator = AnimatorUT.forProgressPercentage(duration, new AnimatorUT.Update() {
            @Override
            public void onUpdate(float progress) {
                int currLeft = (int) (startLeft + progress * leftCut + 0.5f);
                int currRight = (int) (startRight + progress * rightCut + 0.5f);
                roverRect.left = currLeft;
                roverRect.right = currRight;
                needReRect = true;
                invalidate();
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onEnd() {
                valueAnimator = null;
                needReRect = false;
            }

            @Override
            public void onCancel() {
                valueAnimator = null;
                needReRect = false;
            }
        });
    }

    /**
     * {@link RoverView#animReVerti(int, int, long)}
     */
    public void animReVerti(int dstTop, int dstBottom) {
        animReVerti(dstTop, dstBottom, 200);
    }

    /**
     * 动画改变roverDrawable rect的纵向属性。
     *
     * @param dstTop    目标top。
     * @param dstBottom 目标bottom。
     * @param duration  动画持续时间。
     */
    public void animReVerti(int dstTop, int dstBottom, long duration) {
        int startTop = roverRect.top;
        int startBottom = roverRect.bottom;
        int topCut = dstTop - startTop;
        int bottomCut = dstBottom - startBottom;
        valueAnimator = AnimatorUT.forProgressPercentage(duration, new AnimatorUT.Update() {
            @Override
            public void onUpdate(float progress) {
                int currTop = (int) (startTop + progress * topCut + 0.5f);
                int currBottom = (int) (startBottom + progress * bottomCut + 0.5f);
                roverRect.top = currTop;
                roverRect.bottom = currBottom;
                needReRect = true;
                invalidate();
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onEnd() {
                valueAnimator = null;
                needReRect = false;
            }

            @Override
            public void onCancel() {
                valueAnimator = null;
                needReRect = false;
            }
        });
    }

    //////////////////////////////////////////////////

    /**
     * 获取roverDrawable。
     */
    public Drawable getRoverDrawable() {
        return roverDrawable;
    }

    /**
     * 获取roverDrawable的rect。
     */
    public Rect getroverRect() {
        return roverRect;
    }

    /**
     * 获取roverDrawable的rect的left。
     */
    public int left() {
        return roverRect.left;
    }

    /**
     * 获取roverDrawable的rect的top。
     */
    public int top() {
        return roverRect.top;
    }

    /**
     * 获取roverDrawable的rect的right。
     */
    public int right() {
        return roverRect.right;
    }

    /**
     * 获取roverDrawable的rect的bottom。
     */
    public int bottom() {
        return roverRect.bottom;
    }
    //--------------------------------------------------
    /*设置相关。*/

    /**
     * 设置roverDrawable的图片。
     *
     * @param drawable 图片。
     */
    public void setRoverDrawable(Drawable drawable) {
        this.roverDrawable = drawable;
    }


    /**
     * 重新调整roverDrawable的rect。
     */
    public void reRect(Rect rect) {
        roverRect = rect;
        setRoverBoundsOptimize();
    }


    /**
     * 重新调整roverDrawable rect的left属性。
     * <p>
     * 调用完请必须调用{@link RoverView#apply()}刷新。
     *
     * @param left 设置rect的left。
     * @return this
     */
    public RoverView reLeft(int left) {
        roverRect.left = left;
        return this;
    }


    /**
     * 重新调整roverDrawable rect的top属性。
     * <p>
     * 调用完请必须调用{@link RoverView#apply()}刷新。
     *
     * @param top 设置rect的top。
     * @return this
     */
    public RoverView reTop(int top) {
        roverRect.top = top;
        return this;
    }


    /**
     * 重新调整roverDrawable rect的right属性。
     * <p>
     * 调用完请必须调用{@link RoverView#apply()}刷新。
     *
     * @param right 设置rect的right。
     * @return this
     */
    public RoverView reRight(int right) {
        roverRect.right = right;
        return this;
    }

    /**
     * 重新调整roverDrawable rect的bottom属性。
     * <p>
     * 调用完请必须调用{@link RoverView#apply()}刷新。
     *
     * @param bottom 设置rect的bottom。
     * @return this
     */
    public RoverView reBottom(int bottom) {
        roverRect.bottom = bottom;
        return this;
    }

    /**
     * 重新调整横向的绘制区域。
     *
     * @param left  roverDrawable rect的left属性。
     * @param right roverDrawable rect的right属性。
     */
    public void reHori(int left, int right) {
        roverRect.left = left;
        roverRect.right = right;
        apply();
    }

    /**
     * 重新调整纵向的绘制区域。
     *
     * @param top    roverDrawable rect的top属性。
     * @param bottom roverDrawable rect的bottom属性。
     */
    public void reVerti(int top, int bottom) {
        roverRect.top = top;
        roverRect.bottom = bottom;
        apply();
    }

    /**
     * 应用roverDrawable的rect。
     */
    public void apply() {
        setRoverBoundsOptimize();
    }

}

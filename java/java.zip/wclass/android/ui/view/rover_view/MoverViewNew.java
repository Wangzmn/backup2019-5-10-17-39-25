package wclass.android.ui.view.rover_view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;

import wclass.android.ui.view.base_view.BaseCustomView;
import wclass.android.util.AnimatorUT;

/**
 * @作者 做就行了！
 * @时间 2019-04-03下午 2:50
 * @该类描述： -
 * 1、一个图片可以显示在view中的任何位置。
 * 2、通过动画改变图片位置的方法：
 * {@link #animReHori}{@link #animReVerti}。
 * （其实还可以直接进行rect整体变化的，我先不写了。）
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 * todo
 * 1、动画时设置bounds写在draw方法中，动画中只做标记作用。
 */
public class MoverViewNew extends BaseCustomView {
    private static final boolean DEBUG = true;
    /**
     * 可移动图片的rect。
     */
    Rect moverRect = new Rect();
    /**
     * 可移动的图片。
     */
    private Drawable moverDrawable;
    /**
     * onDraw方法中，判断是否需要调整drawable的rect。
     */
    private boolean needReRect = true;

    //////////////////////////////////////////////////
    public MoverViewNew(Context context) {
        super(context);
    }
    //////////////////////////////////////////////////

    /**
     * 获取moverDrawable的rect。
     */
    protected Rect getMoverRect() {
        return moverRect;
    }
    //////////////////////////////////////////////////

    @Override
    protected void onDrawAll(Canvas canvas) {
        super.onDrawAll(canvas);
        if (moverDrawable != null) {
            //需要重新设置rect。
            if (needReRect) {
                moverDrawable.setBounds(moverRect);
            }
            preDrawMover(canvas);
            onDrawMover(canvas, moverDrawable);
        }
    }

    /**
     * 该方法中绘制moverDrawable。
     */
    protected void onDrawMover(Canvas canvas, Drawable moverDrawable) {
        if (DEBUG) {
            Log.e("TAG", getClass() + "#onDrawMover");
        }
        moverDrawable.draw(canvas);
    }

    /**
     * 绘制moverDrawable之前，该方法被调用。
     */
    protected void preDrawMover(Canvas canvas) {

    }

    //--------------------------------------------------

    /**
     * 设置moverDrawable的rect，并刷新显示。
     */
    private void setMoverBoundsOptimize() {
        if (moverDrawable != null) {
            cleanAnim();
            needReRect = true;
            invalidate();
        }
    }

    //////////////////////////////////////////////////
    /*动画相关。*/
    /**
     * 操作moverDrawable rect的动画对象。
     */
    private ValueAnimator valueAnimator;

    /**
     * 清除动画。
     */
    protected void cleanAnim() {
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
    }

    /**
     * {@link MoverViewNew#animReHori(int, int, long)}
     */
    protected void animReHori(int dstLeft, int dstRight) {
        animReHori(dstLeft, dstRight, 200);
    }

    /**
     * 动画改变moverDrawable rect的横向属性。
     *
     * @param dstLeft  目标left。
     * @param dstRight 目标right。
     * @param duration 动画持续时间。
     */
    protected void animReHori(int dstLeft, int dstRight, long duration) {

        int startLeft = moverRect.left;
        int startRight = moverRect.right;
        int leftCut = dstLeft - startLeft;
        int rightCut = dstRight - startRight;
        valueAnimator = AnimatorUT.forProgressPercentage(duration, new AnimatorUT.Update() {
            @Override
            public void onUpdate(float progress) {
                int currLeft = (int) (startLeft + progress * leftCut + 0.5f);
                int currRight = (int) (startRight + progress * rightCut + 0.5f);
                moverRect.left = currLeft;
                moverRect.right = currRight;
                needReRect = true;
                invalidate();
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onEnd() {
                valueAnimator = null;
                needReRect = false;
            }

            @Override
            public void onCancel() {
                valueAnimator = null;
                needReRect = false;
            }
        });
    }

    /**
     * {@link MoverViewNew#animReVerti(int, int, long)}
     */
    protected void animReVerti(int dstTop, int dstBottom) {
        animReVerti(dstTop, dstBottom, 200);
    }

    /**
     * 动画改变moverDrawable rect的纵向属性。
     *
     * @param dstTop    目标top。
     * @param dstBottom 目标bottom。
     * @param duration  动画持续时间。
     */
    protected void animReVerti(int dstTop, int dstBottom, long duration) {
        if(duration<0){
            duration = 0;
        }
        int startTop = moverRect.top;
        int startBottom = moverRect.bottom;
        int topCut = dstTop - startTop;
        int bottomCut = dstBottom - startBottom;
        valueAnimator = AnimatorUT.forProgressPercentage(duration, new AnimatorUT.Update() {
            @Override
            public void onUpdate(float progress) {
                int currTop = (int) (startTop + progress * topCut + 0.5f);
                int currBottom = (int) (startBottom + progress * bottomCut + 0.5f);
                moverRect.top = currTop;
                moverRect.bottom = currBottom;
                needReRect = true;
                invalidate();
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onEnd() {
                valueAnimator = null;
                needReRect = false;
            }

            @Override
            public void onCancel() {
                valueAnimator = null;
                needReRect = false;
            }
        });
    }

    /**
     * 动画改变moverDrawable rect。
     *
     * @param dstRect 目标rect属性。
     */
    protected void animReRect(Rect dstRect) {
        animReRect(dstRect, 200);
    }

    /**
     * 动画改变moverDrawable rect。
     *
     * @param dstRect  目标rect属性。
     * @param duration 动画持续时间。
     */
    protected void animReRect(Rect dstRect, long duration) {
        animReRect(dstRect.left, dstRect.right, dstRect.top, dstRect.bottom,
                duration);
    }

    /**
     * 动画改变moverDrawable rect。
     *
     * @param dstLeft   目标left。
     * @param dstRight  目标right。
     * @param dstTop    目标top。
     * @param dstBottom 目标bottom。
     */
    protected void animReRect(int dstLeft, int dstRight,
                              int dstTop, int dstBottom) {
        animReRect(dstLeft, dstRight, dstTop, dstBottom, 200);
    }

    /**
     * 动画改变moverDrawable rect。
     *
     * @param dstLeft   目标left。
     * @param dstRight  目标right。
     * @param dstTop    目标top。
     * @param dstBottom 目标bottom。
     * @param duration  动画持续时间。
     */
    protected void animReRect(int dstLeft, int dstRight,
                              int dstTop, int dstBottom, long duration) {
        if(duration<0){
            duration = 0;
        }
        int startLeft = moverRect.left;
        int startRight = moverRect.right;
        int startTop = moverRect.top;
        int startBottom = moverRect.bottom;

        int leftCut = dstLeft - startLeft;
        int rightCut = dstRight - startRight;
        int topCut = dstTop - startTop;
        int bottomCut = dstBottom - startBottom;
        valueAnimator = AnimatorUT.forProgressPercentage(duration, new AnimatorUT.Update() {
            @Override
            public void onUpdate(float progress) {
                int currLeft = (int) (startLeft + progress * leftCut + 0.5f);
                int currRight = (int) (startRight + progress * rightCut + 0.5f);
                int currTop = (int) (startTop + progress * topCut + 0.5f);
                int currBottom = (int) (startBottom + progress * bottomCut + 0.5f);
                moverRect.left = currLeft;
                moverRect.right = currRight;
                moverRect.top = currTop;
                moverRect.bottom = currBottom;
                needReRect = true;
                invalidate();
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onEnd() {
                valueAnimator = null;
                needReRect = false;
            }

            @Override
            public void onCancel() {
                valueAnimator = null;
                needReRect = false;
            }
        });
    }
    //////////////////////////////////////////////////

    /**
     * 获取moverDrawable。
     */
    protected Drawable getMoverDrawable() {
        return moverDrawable;
    }

    /**
     * 获取moverDrawable的rect的left。
     */
    protected int left() {
        return moverRect.left;
    }

    /**
     * 获取moverDrawable的rect的top。
     */
    protected int top() {
        return moverRect.top;
    }

    /**
     * 获取moverDrawable的rect的right。
     */
    protected int right() {
        return moverRect.right;
    }

    /**
     * 获取moverDrawable的rect的bottom。
     */
    protected int bottom() {
        return moverRect.bottom;
    }
    //--------------------------------------------------
    /*设置相关。*/

    /**
     * 设置moverDrawable的图片。
     *
     * @param drawable 图片。
     */
    protected void setMoverDrawable(Drawable drawable) {
        this.moverDrawable = drawable;
    }


    /**
     * 重新调整moverDrawable的rect。
     */
    protected void reRect(Rect rect) {
        moverRect.set(rect);
        setMoverBoundsOptimize();
    }


    /**
     * 重新调整moverDrawable rect的left属性。
     * <p>
     * 调用完请必须调用{@link MoverViewNew#apply()}刷新。
     *
     * @param left 设置rect的left。
     * @return this
     */
    protected MoverViewNew reLeft(int left) {
        moverRect.left = left;
        return this;
    }


    /**
     * 重新调整moverDrawable rect的top属性。
     * <p>
     * 调用完请必须调用{@link MoverViewNew#apply()}刷新。
     *
     * @param top 设置rect的top。
     * @return this
     */
    protected MoverViewNew reTop(int top) {
        moverRect.top = top;
        return this;
    }


    /**
     * 重新调整moverDrawable rect的right属性。
     * <p>
     * 调用完请必须调用{@link MoverViewNew#apply()}刷新。
     *
     * @param right 设置rect的right。
     * @return this
     */
    protected MoverViewNew reRight(int right) {
        moverRect.right = right;
        return this;
    }

    /**
     * 重新调整moverDrawable rect的bottom属性。
     * <p>
     * 调用完请必须调用{@link MoverViewNew#apply()}刷新。
     *
     * @param bottom 设置rect的bottom。
     * @return this
     */
    protected MoverViewNew reBottom(int bottom) {
        moverRect.bottom = bottom;
        return this;
    }

    /**
     * 重新调整横向的绘制区域。
     *
     * @param left  moverDrawable rect的left属性。
     * @param right moverDrawable rect的right属性。
     */
    protected void reHori(int left, int right) {
        moverRect.left = left;
        moverRect.right = right;
        apply();
    }

    /**
     * 重新调整纵向的绘制区域。
     *
     * @param top    moverDrawable rect的top属性。
     * @param bottom moverDrawable rect的bottom属性。
     */
    protected void reVerti(int top, int bottom) {
        moverRect.top = top;
        moverRect.bottom = bottom;
        apply();
    }

    /**
     * 应用moverDrawable的rect。
     */
    protected void apply() {
        setMoverBoundsOptimize();
    }

}

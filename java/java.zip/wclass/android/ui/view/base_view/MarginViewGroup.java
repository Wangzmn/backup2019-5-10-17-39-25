package wclass.android.ui.view.base_view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/**
 * @作者 做就行了！
 * @时间 2019-04-09下午 9:18
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
@SuppressWarnings("DanglingJavadoc")
public abstract class MarginViewGroup extends BaseViewGroup {

    //--------------------------------------------------
    /**{@link #onMeasure}中，可使用方法。*/
    /**
     * 包括margin在内测量孩子的宽高，每个孩子独立测量，互不影响。
     *
     * @param widthMeasureSpec  {@link View#onMeasure(int, int)}
     * @param heightMeasureSpec {@link View#onMeasure(int, int)}
     */
    protected void measureChildrenWithMarginsSelfish(int widthMeasureSpec, int heightMeasureSpec) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = getChildAt(i);
            if (child.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                measureChildWithMargins(child, widthMeasureSpec, 0,
                        heightMeasureSpec, 0);
            } else {
                measureChild(child, widthMeasureSpec, heightMeasureSpec);
            }
        }
    }
    //////////////////////////////////////////////////

    /**
     * 获取子view布局时的宽。
     *
     * @param child       子view。
     * @param childParams 子view的params。
     * @return 获取子view布局时的宽。
     */
    protected int getLayoutWidth(View child, ViewGroup.LayoutParams childParams) {
        if (childParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams childParams1 = (ViewGroup.MarginLayoutParams) childParams;
            return child.getMeasuredWidth() + childParams1.leftMargin + childParams1.rightMargin;
        } else {
            return child.getMeasuredWidth();
        }
    }

    /**
     * 获取子view布局时的高。
     *
     * @param child       子view。
     * @param childParams 子view的params。
     * @return 获取子view布局时的宽。
     */
    protected int getLayoutHeight(View child, ViewGroup.LayoutParams childParams) {
        if (childParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams childParams1 = (ViewGroup.MarginLayoutParams) childParams;
            return child.getMeasuredHeight() + childParams1.topMargin + childParams1.bottomMargin;
        } else {
            return child.getMeasuredHeight();
        }
    }

    //--------------------------------------------------
    @Override
    protected ViewGroup.MarginLayoutParams generateLayoutParams(ViewGroup.LayoutParams p) {
        return new ViewGroup.MarginLayoutParams(p);
    }

    @Override
    protected ViewGroup.MarginLayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    @Override
    public ViewGroup.MarginLayoutParams generateLayoutParams(AttributeSet attrs) {
        return new ViewGroup.MarginLayoutParams(getContext(), attrs);
    }

    //////////////////////////////////////////////////
    public MarginViewGroup(Context context) {
        super(context);
    }

    public MarginViewGroup(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MarginViewGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}

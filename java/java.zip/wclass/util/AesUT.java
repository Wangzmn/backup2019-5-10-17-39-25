package wclass.util;

/**
 * @作者 做就行了！
 * @时间 2019-03-09下午 10:34
 * @该类描述： -
 * 1、与美学相关的数值常量类。
 * 2、Aes = Aesthetics。
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class AesUT {
    public static final float GOLDEN_RATIO = 0.618f;
}

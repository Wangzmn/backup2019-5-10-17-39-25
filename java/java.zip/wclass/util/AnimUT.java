package wclass.util;

/**
 * @作者 做就行了！
 * @时间 2019/1/15 0015 下午 4:37
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 */
public class AnimUT {
    public static final long DEFAULT_DURATION = 200;
}
package wclass.util;

/**
 * @作者 做就行了！
 * @时间 2019-03-19下午 3:00
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class RatioUT {
    public static final float METER_2_INCH = 39.37f;
    public static final float DM_2_INCH = 3.937f;
    public static final float CM_2_INCH = .3937f;
    public static final float MM_2_INCH = .03937f;
}
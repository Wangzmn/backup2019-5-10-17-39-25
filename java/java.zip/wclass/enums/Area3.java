package wclass.enums;

/**
 * 所在的区域。
 */
public enum Area3 {
    START,    //前端
    MID,    //中间
    END     //后端
}
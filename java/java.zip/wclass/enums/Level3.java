package wclass.enums;

/**
 * @作者 做就行了！
 * @时间 2019/1/28 0028
 * @使用说明：
 */
public enum Level3 {
    NORMAL,
    BETTER,
    BEST
}

package wclass.enums;

/**
 * @作者 做就行了！
 * @时间 2019/1/12 0012 下午 3:57
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 */
public enum Result {
    TRUE,//结果为true。
    FALSE,//结果为false。
    PENDING//结果待验证。
}
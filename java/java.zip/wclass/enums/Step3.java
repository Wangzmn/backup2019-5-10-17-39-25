package wclass.enums;

/**
 * @作者 做就行了！
 * @时间 2018-12-23下午 5:04
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 */
public enum Step3 {
    BEGIN,  //开始
    ING,    //持续中
    FINISH    //结束
}
package wclass.enums;

/**
 * @作者 做就行了！
 * @时间 2018-12-27下午 10:51
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 */
public enum Orien5 {
    TOP,    //向上
    BOTTOM, //向下
    LEFT,   //向左
    RIGHT,  //向右
    SITU;   //原地不动
}
package wclass.enums;

/**
 * @作者 做就行了！
 * @时间 2018-10-08下午 11:01
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 */
public enum Where3 {
    BEFORE, //往之前
    AFTER,  //往之后
    SITU    //原地不动
}
package wclass.z_pending_class.data;

/**
 * @作者 做就行了！
 * @时间 2018/12/7 0007 下午 5:23
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 */
public class z_none {
}
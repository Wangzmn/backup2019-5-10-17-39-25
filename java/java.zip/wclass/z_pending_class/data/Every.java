package wclass.z_pending_class.data;

/**
 * @作者 做就行了！
 * @时间 2019/1/22 0022 下午 4:39
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 */
public interface Every<T> {
    void onItem(T item);
}
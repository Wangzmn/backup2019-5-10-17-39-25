package wclass.z_pending_class.data;

/**
 * @作者 做就行了！
 * @时间 2018/12/5 0005
 * @使用说明：
 */
public interface GenerateDataListener<T> {
    T onGenerateData(int position);
}

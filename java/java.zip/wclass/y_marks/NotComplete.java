package wclass.y_marks;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * @作者 做就行了！
 * @时间 2019-01-07下午 10:29
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 */
@Retention(RetentionPolicy.SOURCE)
public @interface NotComplete {
}

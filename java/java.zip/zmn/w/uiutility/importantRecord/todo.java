package zmn.w.uiutility.importantRecord;

import android.widget.FrameLayout;

import zmn.w.uiutility.main_class.window.Window;

/**
 * @作者 做就行了！
 * @时间 2019/1/25 0025
 * @使用说明：
 */
public class todo {
    /**
     * todo aspect
     * 1、{@link Window}
     *    该类运行成功后，将已使用的方法，改成“运行于”。
     * 2、写一个{@link Drawable}类，用于DEBUG时调试。
     *    该类特点：可以出现文字~~~~~
     */
    /**
     * todo custom
     * 1、用户自定义相关：
     * ①用户自定义图片：图片大小、圆角大小。
     * ②该图片的前景：可自定义图片、简单的描边（描边粗细、圆角、整体大小）。
     * ③用{@link FrameLayout}嵌套实现。
     * ④可设置图片透明度。（描边的颜色中包含透明度，所依描边不需要颜色。）
     */
}

package zmn.w.uiutility.importantRecord.z_mistake;

import android.view.View;

/**
 * @作者 做就行了！
 * @时间 2019/1/26 0026
 * @使用说明：
 */
public class little {
    /**
     * 0x0000ff：透明。
     * 0xff0000ff：不透明。
     */
    /**
     * {@link View#onSizeChanged(int, int, int, int)}
     * 1、在该方法中调整孩子大小时，会导致孩子不显示。
     */
}

package zmn.w.uiutility.importantRecord.z_mistake.android;

/**
 * @作者 做就行了！
 * @时间 2019/2/15 0015
 * @使用说明：
 */
public class mistake {
    //step 使用application级别的context启动startActivity！！！
    //step startActivity()方法：
    {
        /**
         * context是acticity用的是activity的任务栈。
         * context是application用的是application的任务栈。
         */
    }
}

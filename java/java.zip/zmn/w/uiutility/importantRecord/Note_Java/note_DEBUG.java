package zmn.w.uiutility.importantRecord.Note_Java;

/**
 * @作者 做就行了！
 * @时间 2019/3/7 0007
 * @使用说明：
 */
public class note_DEBUG {
    /**
     * step 技巧：
     * 1、toString方法会显示在debug列表中，
     *    重写类的toString方法，便于调试。
     */
}

package zmn.w.uiutility.importantRecord.Note_Java;

/**
 * @作者 做就行了！
 * @时间 2019/1/31 0031
 * @使用说明：
 */
public class note_Thread {
    {
        /**
         * {@link Thread#threadLocals}
         * 1、该字段在{@link ThreadLocal#get()}
         */
    }
}

package zmn.w.uiutility.importantRecord.Note_Android;

import android.widget.FrameLayout;

/**
 * @作者 做就行了！
 * @时间 2019/2/3 0003
 * @使用说明：
 */
public class note_FrameLayout {
    /**
     * 1、{@link FrameLayout}没有“setGravity”类型的方法。
     *    但是：{@link FrameLayout.LayoutParams#gravity}。
     */
}

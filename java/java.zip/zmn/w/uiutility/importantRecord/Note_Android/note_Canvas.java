package zmn.w.uiutility.importantRecord.Note_Android;

import android.graphics.Paint;

/**
 * @作者 做就行了！
 * @时间 2019/2/6 0006
 * @使用说明：
 */
public class note_Canvas {
    /**
     * {@link Paint#setStrokeWidth(float)}
     * 1、sWidth的一半在外，一半在内。
     * 2、如果需要完全的画在canvas上，需要将画布缩小sWidth宽度，
     *    这样的话，外边的sWidth就可以完全显示了。
     */
}

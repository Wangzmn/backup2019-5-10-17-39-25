package zmn.w.uiutility.importantRecord.Note_Android;

/**
 * @作者 做就行了！
 * @时间 2019/1/30 0030
 * @使用说明：
 */
public class note_ResolveInfo {
    /**
     * 包名获取方法：resolve.activityInfo.packageName
     * icon获取获取方法：resolve.loadIcon(packageManager)
     * 应用名称获取方法：resolve.loadLabel(packageManager).toString()
     */
}

package zmn.w.uiutility.importantRecord.Note_Android;

import android.graphics.Bitmap;

/**
 * @作者 做就行了！
 * @时间 2019/3/28 0028
 * @使用说明：
 */
public class note_Bitmap {
    /**
     * step
     * 1、{@link Bitmap#recycle()}
     *    该方法不可逆转。
     * 2、用时在创建。
     * 3、控件多大，就创建多大的bitmap！！！
     *    警告：不能根据实际图片的尺寸设置Bitmap的大小！！！
     */
}

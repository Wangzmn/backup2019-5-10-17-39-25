package zmn.w.uiutility.main_class.window_plugin_view;

/**
 * @作者 做就行了！
 * @时间 2019-02-19上午 12:02
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class ResizableView2 {

}

package view_pager;

import android.view.View;

/**
 * @作者 做就行了！
 * @时间 2019/4/28 0028
 * @使用说明：
 */
public class ItemInfo {
    View view;
    boolean needLayout
}

package view_pager;

/**
 * @作者 做就行了！
 * @时间 2019/4/28 0028
 * @使用说明：
 */
public class SelfClass {
    /**
     * step 用IntMap。
     * 1、在关键处打印日志。
     * ①加载一页后。
     * ②执行某些操作后。
     */
}

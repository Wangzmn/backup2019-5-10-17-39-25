package flow_layout;

import android.animation.Animator;
import android.content.Context;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import wclass.android.ui.view.base_view.MarginViewGroup;


/**
 * 加油吧，你是最最最最有个性的 ~ ！！！
 *
 * @作者 做就行了！
 * @时间 2019-04-09下午 8:46
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
@SuppressWarnings("DanglingJavadoc")
public class FlowLayout extends MarginViewGroup {
    private static final boolean DEBUG = true;
    private boolean layouted;
    /**
     * step 思路：
     * 1、通过XY布局。
     * 解释：删除item时，可以将其他item通过动画改变坐标。
     */
    /**
     * todo
     * 1、onLayout中measure！！！
     * 2、最好写个adapter类型的！！！
     * 3、通过adapter init后，
     * 直接在addItem/delItem方法中操作指定item，并执行动画！！！
     * 如果未初始化时，用户add/del，抛出异常。
     */
    /**
     * todo 所有问题：
     * 1、只有一个item时，怎么添加这个item？
     * 解决：如果该行没有item，就可以添加。
     * 2、怎么接着上一个直接布局？？？
     */

    public FlowLayout(Context context) {
        super(context);
    }

    //    List<View> items = new ArrayList<>();
    List<Holder> holders = new ArrayList<>();

    public void addItem(View item) {
        addView(item);
        holders.add(new Holder(item));
        int position = holders.size() - 1;
        updateItemParams(position);
        onAddLastItem(position);
//        optimizeLayout(position);
    }


    public void insertItem(View item, int position) {
        addView(item);
        holders.add(position, new Holder(item));
        updateItemParams(position);
        onInsertItem(position);
//        optimizeLayout(position);
    }


    public void removeItem(View item) {
//        removeView(item);
        int position = removeInHolders(item);
        if (position != -1) {
            updateItemParams(position);
            onRemoveItem(item, position);
        }
    }

    public void removeItem(int position) {
        Holder holder = holders.remove(position);
        if (holder != null) {
//            removeView(holder.item);
            updateItemParams(position);
            onRemoveItem(holder.item, position);
        }

    }

    /**
     * 删除items。
     *
     * @param removes
     */
    public void removeItems(List<View> removes) {
        if (removes == null || removes.size() == 0) {
            return;
        }
        //从ViewGroup中删除。
        for (View remove : removes) {
            removeView(remove);
        }
        //从集合类中删除
        int minDex = removeInHolders(removes);
        if (minDex != -1) {
            updateItemParams(minDex);
            onRemoveItems(removes, minDex);
            onRemovePendingLayout(holders, minDex);
        } else {
            Log.e("TAG", getClass() + "#getMinDex:" +
                    " 错误：未找到待删除的最小dex的item。 ");
        }
    }
    //////////////////////////////////////////////////

    /**
     * 添加最后一个item时会被调用。
     */
    protected void onAddLastItem(int position) {
        if (!layouted) {
            return;
        }
        Holder holder = holders.get(position);
        holder.layout();
    }

    /**
     * 插入一个item时会被调用。
     *
     * @param position 新item插入的位置。
     */
    protected void onInsertItem(int position) {
        if (!layouted) {
            return;
        }
        for (int i = position; i < holders.size(); i++) {
            Holder holder = holders.get(i);
            holder.layout();
        }
    }

    /**
     * 删除item时会被调用。
     * <p>
     * 警告：必须在该方法中{@link #removeView}。
     *
     * @param pendingRemove 待删除的item。
     * @param position      该item的位置。
     */
    protected void onRemoveItem(View pendingRemove, int position) {
        if (!layouted) {
            return;
        }
        for (int i = position; i < holders.size(); i++) {
            Holder holder = holders.get(i);
            holder.layout();
        }
        removeView(pendingRemove);
    }

    /**
     * 删除items时会被调用。
     * <p>
     * 警告：必须在该方法中{@link #removeView}。
     *
     * @param pendingRemoves 待删除的items。
     * @param minDex         下标最小的item的下标。
     */
    protected void onRemoveItems(List<View> pendingRemoves, int minDex) {
        if (!layouted) {
            return;
        }
        for (int i = minDex; i < holders.size(); i++) {
            Holder holder = holders.get(i);
            holder.layout();
        }
        for (View pendingRemove : pendingRemoves) {
            removeView(pendingRemove);
        }
    }
    //////////////////////////////////////////////////

    /**
     * 删除items，并获取待删除的items中，最小下标的item的下标。
     *
     * @param removes 待删除的items。
     * @return 待删除的items中最小下标的item的下标。
     */
    private int removeInHolders(List<View> removes) {
        int min = -1;
        for (int j = removes.size() - 1; j >= 0; j--) {
            View remove = removes.get(j);
            for (int i = holders.size() - 1; i >= 0; i--) {
                Holder holder = holders.get(i);
                if (holder.item == remove) {
                    if (min == -1) {
                        min = i;
                    }
                    holders.remove(i);
                    min = Math.min(i, min);
                    break;
                }
            }
        }
        return min;
    }

    /**
     * 从本类的集合类中删除。
     *
     * @param item 待删除。
     * @return item的下标。
     */
    private int removeInHolders(View item) {
        for (int i = 0; i < holders.size(); i++) {
            Holder holder = holders.get(i);
            if (holder.item == item) {
                holders.remove(i);
                return i;
            }
        }
        return -1;
    }

    protected void onRemovePendingLayout(List<Holder> holders, int fromDex) {

    }

    private void optimizeLayout(int position) {

    }

    //////////////////////////////////////////////////

    /**
     * 暂时先这样写。
     * <p>
     * 改进：以后改成每个item的animation动画。
     */
    Animator anim;

    private void animToXY(int fromPosition, int toPosition) {

        for (int i = fromPosition; i < holders.size(); i++) {
            Holder holder = holders.get(i);
            holder.item.animate().x(holder.itemX).y(holder.itemY)
                    .setDuration(200).start();
        }
    }

    private void cleanAnim() {
        if (anim != null) {
            anim.cancel();
            anim = null;
        }
    }

    //////////////////////////////////////////////////
    @SuppressWarnings("all")
    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        /*确定*/

        int childCount = holders.size();
        if (childCount == 0) {
            return;
        }

        //如果条件满足，则执行完全的重新布局。
        if (!(changed || isLayoutRequested())) {
            return;
        }
        cleanAnim();
        layouted = true;
        int widthMeasureSpec = getMeasuredWidthAndState();
        int heightMeasureSpec = getMeasuredHeightAndState();
        measureChildrenWithMarginsSelfish(widthMeasureSpec, heightMeasureSpec);
        updateItemParams(0);
        updateItemParams(0,true);
        if (DEBUG) {
            Log.e("TAG", " childCount = " + childCount);
        }
    }

    private void updateItemParams(int fromPosition) {
        updateItemParams(fromPosition,false);
    }

    private void updateItemParams(int fromPosition,boolean layout) {
        if (!layouted || fromPosition < 0) return;
        int usableWidth = getUsableWidth();
        RowInfo rowInfo = correctRowInfoWithBefore(fromPosition - 1);
        int paddingLeft = getPaddingLeft();
        for (int i = fromPosition; i < holders.size(); i++) {
            Holder holder = holders.get(i);
            View child = holder.item;
            LayoutParams p = child.getLayoutParams();
            int cw = child.getMeasuredWidth();
            int ch = child.getMeasuredHeight();

            int cLayoutWidth = getLayoutWidth(child, p);
            /**
             * 已使用的行宽+待布局的child的宽，大于可使用的行宽。
             * 此时应该换行。
             * 该行至少有一个item。
             */
            if (rowInfo.itemCount != 0
                    && rowInfo.usedWidth + cLayoutWidth > usableWidth) {
                rowInfo = new RowInfo(rowInfo.rowDex + 1,
                        rowInfo.rowBottom());
                rowInfo.usedWidth = paddingLeft;
            }
            //fix 这里没布局。
//            child.layout(0, 0, cw, ch);
            //step1
            holder.re(child, rowInfo.usedWidth, rowInfo.rowTop, cw, ch, p);
            //step2
            updateRowInfoByAdd(rowInfo, holder);
            //step3
            holder.rowInfo = rowInfo;
            holders.set(i, holder);
            if(layout){
                holder.layout();
            }
            if (DEBUG) {
                Log.e("TAG", " holder" + i +
                        " = " + holder);
            }
        }
    }

    /**
     * 添加每一行添加item后，更新行信息类。
     *
     * @param rowInfo {@link RowInfo}。
     * @param holder  新添加的item。
     */
    private void updateRowInfoByAdd(RowInfo rowInfo, Holder holder) {
        rowInfo.itemCount++;
        rowInfo.rowH = Math.max(rowInfo.rowH, holder.layH);//取该行最高的child的高。
        rowInfo.usedWidth = holder.layRight();
    }

    /**
     * 从指定item开始，往之前找相同行的item，并更新行信息{@link RowInfo}。
     *
     * @param fromPosition 从指定item开始，往之前找。
     * @return 行信息类。
     */
    private RowInfo correctRowInfoWithBefore(int fromPosition) {
        if (fromPosition < 0) {
            RowInfo rowInfo = new RowInfo(0, getPaddingTop());
            rowInfo.usedWidth = getPaddingLeft();
            return rowInfo;
        }
        //往之前寻找与该item下标相同的item。
        Holder holder = holders.get(fromPosition);
        RowInfo rowInfo = holder.rowInfo;
        int maxHeight = 0;
        int count = 1;//数量中包含请求的position。

        //总前一个往之前找。
        for (int i = fromPosition - 1; i >= 0; i--) {
            Holder holderI = holders.get(i);
            RowInfo rowInfoI = holderI.rowInfo;
            //item都在同一行时，高度取最大。
            if (rowInfoI == rowInfo) {
                maxHeight = Math.max(maxHeight, holderI.itemH);
                count++;
            }
            //item不再同一行，找完了。
            else {
                break;
            }
        }
        rowInfo.itemCount = count;
        rowInfo.rowH = maxHeight;
        rowInfo.usedWidth = holder.layRight();
        return rowInfo;
    }

    //////////////////////////////////////////////////

    /**
     * todo 将该类独立出来。（rowInfo是子类的属性。）
     */
    public class Holder {
        View item;//holder持有的item。

        /**
         * 布局时的X坐标。
         */
        int layX;

        /**
         * 布局时的Y坐标。
         */
        int layY;

        /**
         * 布局需要的宽。
         */
        int layW;

        /**
         * 布局需要的高。
         */
        int layH;

        int itemX, itemY;//item的XY坐标。
        int itemW, itemH;//item的宽高。
        int layRight;
        int layBottom;


        //item的上下左右外边距。
        int leftMargin, rightMargin, topMargin, bottomMargin;
        //        int layoutW,layoutH;
        /**
         * item的行信息。
         */
        RowInfo rowInfo;

        //////////////////////////////////////////////////
        Holder(View item) {
            this.item = item;
        }

        Holder(View item, int layX, int layY, int childW, int childH,
               LayoutParams p1) {
            constructor(item, layX, layY, childW, childH, p1);
        }

        void re(View item, int layX, int layY, int childW, int childH,
                LayoutParams p1) {
            constructor(item, layX, layY, childW, childH, p1);
        }

        private void constructor(View item, int layX, int layY, int childW, int childH, LayoutParams p1) {
            if (p1 instanceof MarginLayoutParams) {
                MarginLayoutParams p = (MarginLayoutParams) p1;
                leftMargin = p.leftMargin;
                rightMargin = p.rightMargin;
                topMargin = p.topMargin;
                bottomMargin = p.bottomMargin;
            }
            this.item = item;
            this.layX = layX;
            this.layY = layY;
            this.layW = childW + leftMargin + rightMargin;
            this.layH = childH + topMargin + bottomMargin;
            itemX = layX + leftMargin;
            itemY = layY + topMargin;
            itemW = childW;
            itemH = childH;

            layRight = layX + layW;
            layBottom = layY + layH;
        }
        //--------------------------------------------------

        @Override
        public String toString() {
            String s = "\nlayX = " + layX + "" +
                    " ,layY = " + layY + "" +
                    " ,layW = " + layW + "" +
                    " ,layH = " + layH + "" +
                    " ,layRight = " + layRight + "" +
                    " ,layBottom = " + layBottom + " ," + "\n" +
                    "itemX = " + itemX + "" +
                    " ,itemY = " + itemY + "" +
                    " ,itemW = " + itemW + "" +
                    " ,itemH = " + itemH + " 。";
            return s;
        }

        //--------------------------------------------------
        void layout() {
            item.layout(0, 0, itemW, itemH);
            item.setX(itemX);
            item.setY(itemY);
        }
        //--------------------------------------------------


        /**
         * 布局时的 Left。
         */
        int layLeft() {
            return layX;
        }

        /**
         * 布局时的 Top。
         */
        int layTop() {
            return layY;
        }

        /**
         * 布局时的 Right。
         */
        int layRight() {
            return layRight;
        }

        /**
         * 布局时的 Bottom。
         */
        int layBottom() {
            return layBottom;
        }

    }
    /**
     * 添加item时做标记。
     */
    /**
     * 1、一行能放下时，计算该行之前item的最大高。
     */
    public class RowInfo {
        final int rowDex;//行所在总行数中的下标。
        final int rowTop;//该行的top所在坐标。
        /**
         * 行高。
         * （最高的那个item，包含item的topMargin和bottomMargin。）
         */
        int rowH;
        int itemCount;//该行item数量。
        int usedWidth;//该行已使用的长度。（包含父容器的leftPadding。）

        public RowInfo(int rowDex1, int rowTop1) {
            rowDex = rowDex1;
            rowTop = rowTop1;
        }

        /**
         * 获取行的bottom坐标。
         * <p>
         * 友情提示：该属性也是下一行的top坐标。
         */
        int rowBottom() {
            return rowTop + rowH;
        }
    }

}

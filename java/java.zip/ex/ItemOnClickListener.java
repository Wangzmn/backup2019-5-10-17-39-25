package ex;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import wclass.android.util.DebugUT;
import wclass.android.z_debug.EventUT;

/**
 * @作者 做就行了！
 * @时间 2019-04-24下午 10:47
 * @该类描述： -
 * 1、给{@link RecyclerView}设置触摸监听，触发点击时，发出回调。
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
@SuppressWarnings("WeakerAccess")
public class ItemOnClickListener implements RecyclerView.OnItemTouchListener {
    private static final boolean DEBUG = false;
    private RecyclerView rv;

    public ItemOnClickListener(RecyclerView rv) {
        this.rv = rv;
        gestureDetector = new GestureDetector(rv.getContext()
                , new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                View child = rv.findChildViewUnder(e.getX(), e.getY());
                if (child != null) {
                    RecyclerView.ViewHolder vh = rv.getChildViewHolder(child);
                    onClick(vh);
                }
                if(DEBUG){
                    String s = DebugUT.toStr_pointersCoor(e);
                    Log.e("TAG",getClass()+"#onSingleTapUp:  "+s+" 。");
                    Log.e("TAG",getClass()+"#onSingleTapUp:" +
                            " 是否找到child："+ (child!=null)+" 。");
                }
                return true;
            }
        });
    }

    protected void onClick(RecyclerView.ViewHolder vh) {
        if (DEBUG) {
            Log.e("TAG", getClass() + "#onClick:" +
                    " vh的position = " + vh.getLayoutPosition() + " 。");
        }
    }

    private GestureDetector gestureDetector;

    @Override
    public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
        if (DEBUG) {
            Log.e("TAG", getClass() + "#onInterceptTouchEvent: " +
                    "" + EventUT.actionToStr(e));
        }
        gestureDetector.onTouchEvent(e);
        return false;
    }

    @Override
    public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        if (DEBUG) {
            Log.e("TAG", getClass() + "#onTouchEvent: " +
                    "" + EventUT.actionToStr(e));
        }
//        gestureDetector.onTouchEvent(e);
    }

    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

    }
}

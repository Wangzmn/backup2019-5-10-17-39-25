package pending.tab_layout;

import android.view.View;
import android.view.ViewGroup;

import wclass.enums.Orien2;

/**
 * @作者 做就行了！
 * @时间 2019-04-20下午 11:27
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public abstract class TabLayoutAdapter<T extends View>  {
    TabLayout tabLayout;
    public abstract void onSelectedTab(T t, int position);


    public abstract void pre(TabLayout tabLayout, int w, int h);
    public abstract int  getTabCount();
    public abstract T onCreateTabView(int position);
//    public abstract void onAdjustTabWH(T t,int position);
    public abstract int getSpaceBefore(int position);
    public abstract WH getTabWH();

    public XY getStartXY() {
        return new XY();
    }

    public abstract Orien2 getOrien();

//    public void onLayoutChild(T t,int position){
//
//    }


}

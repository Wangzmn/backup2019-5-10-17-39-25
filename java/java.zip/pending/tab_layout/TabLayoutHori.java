package pending.tab_layout;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import wclass.android.ui.view.rover_view.MoverView;
import wclass.android.util.ViewUT;
import wclass.enums.Where2;
import wclass.util.ColorUT;

/**
 * @作者 做就行了！
 * @时间 2019/4/3 0003
 * @使用说明：
 */
public abstract class TabLayoutHori<T extends View> extends TabLayout<T> {

    /**
     * todo 待解决：
     * 1、选中的tab改变时，可以自定义指示器的滑动动画。
     */
    //////////////////////////////////////////////////
    private static final boolean DEBUG = true;
    /**
     * 作为indicator的容器。
     */
    MoverView moverView;
    private final Context context;//上下文。
    //--------------------------------------------------
    private TabLayoutAdapterEX<T> adapter;
    //////////////////////////////////////////////////

    public TabLayoutHori(Context context, int tabCount) {
        super(context);
        this.context = context;
    }
    //////////////////////////////////////////////////

    @Override
    public void setAdapter(TabLayoutAdapter<T> adapter) {
        throw new IllegalStateException();
    }

    public void setAdapter(TabLayoutAdapterEX<T> adapter) {
        super.setAdapter(adapter);
        this.adapter = adapter;
    }


    @SuppressWarnings("WeakerAccess")
    public static abstract class TabLayoutAdapterEX<T extends View> extends TabLayoutAdapter<T> {
        public abstract int getIndicatorHolderSize();


        public void onReRectIndicator(MoverView moverView, TabInfo selectedTab) {
            Rect rect = selectedTab.rect;
            int left = rect.left;
            int right = rect.right;
            moverView.reRect(left, 0, right, moverView.getHeight());
        }

        public MoverView onCreateIndicator() {
            return new MoverView(getTabLayout().getContext());
        }
    }

    //////////////////////////////////////////////////

    @Override
    protected void onInit() {
        super.onInit();
        moverView = adapter.onCreateIndicator();
        addView(moverView);
        if (DEBUG) {
            moverView.setBackgroundColor(ColorUT.BLUE);
            moverView.setMoverDrawable(new ColorDrawable(ColorUT.RED));
        }
    }

    @Override
    protected void onLayoutOptimize() {
        super.onLayoutOptimize();
        layoutMover();
    }

    Rect moverDrawableRect = new Rect();

    private void layoutMover() {
        if(moverView==null){
            return;
        }
        /*布局下划线容器。*/
        int indicatorHolderSize = adapter.getIndicatorHolderSize();
        int width = getWidth();
        int height = getHeight();

        int left = 0;
        int top = height - indicatorHolderSize;
        int right = width;
        int bottom = height;

        ViewUT.adjustSize(moverView, width, indicatorHolderSize);
        measureChild(moverView);
        moverView.layout(left, top, right, bottom);
        //--------------------------------------------------
        /*设置下划线drawable的rect。*/
        TabInfo selectedTab = getSelectedTab();
        adapter.onReRectIndicator(moverView, selectedTab);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (DEBUG) {
            if(moverView==null){
                return super.dispatchTouchEvent(ev);
            }
            Rect rect = new Rect();
            moverView.getHitRect(rect);
            Log.e("TAG", " moverViewRect = " + rect);
            Log.e("TAG", " moverDrawableRect = " + moverDrawableRect);
        }
        return super.dispatchTouchEvent(ev);
    }

    //////////////////////////////////////////////////
    /*indicator动画相关*/
    @Override
    protected void onSelectedChanged(TabInfo newTab, TabInfo oldTab, boolean fromTouch) {
        super.onSelectedChanged(newTab, oldTab, fromTouch);

        switch (getOrien()) {
            case HORIZONTAL:
                if (moverView != null) {
                    Rect rect = newTab.rect;
                    moverView.animReHori(rect.left, rect.right);
                }
                break;
            case VERTICAL:
                break;
            default:
                throw new IllegalStateException();
        }
    }

}

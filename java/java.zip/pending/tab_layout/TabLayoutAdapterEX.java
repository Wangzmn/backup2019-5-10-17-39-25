package pending.tab_layout;

/**
 * @作者 做就行了！
 * @时间 2019-04-22下午 5:13
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public abstract class TabLayoutAdapterEX extends TabLayoutAdapter {
    public abstract int getLineHeight();
}

package test;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * @作者 做就行了！
 * @时间 2019/4/27 0027
 * @使用说明：
 */
public abstract class FragmentEX extends Fragment {

    private static final boolean DEBUG = true;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        if(DEBUG){
            Log.e("TAG",getClass()+"#onCreate:" +
                    " subClass:"+ getSubClassName()+" 。");
        }
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        if(DEBUG){
            Log.e("TAG",getClass()+"#onCreateView:" +
                    " subClass:"+ getSubClassName()+" 。");
        }
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();

        if(DEBUG){
            Log.e("TAG",getClass()+"#onResume:" +
                    " subClass:"+ getSubClassName()+" 。");
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if(DEBUG){
            Log.e("TAG",getClass()+"#onPause:" +
                    " subClass:"+ getSubClassName()+" 。");
        }
    }

    @Override
    public void onStop() {
        super.onStop();

        if(DEBUG){
            Log.e("TAG",getClass()+"#onStop:" +
                    " subClass:"+ getSubClassName()+" 。");
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if(DEBUG){
            Log.e("TAG",getClass()+"#setUserVisibleHint:" +
                    " subClass:"+ getSubClassName()+" 。" +
                    " isVisibleToUser:"+isVisibleToUser+" 。");
        }
        if(isVisibleToUser){

        }
        //对用户不可见
        else{

        }
    }

    public abstract String getSubClassName();
}

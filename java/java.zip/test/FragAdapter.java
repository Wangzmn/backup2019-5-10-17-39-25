package test;

/**
 * @作者 做就行了！
 * @时间 2019/4/27 0027
 * @使用说明：
 */
public class FragAdapter extends FragmentPagerAdapter {
}

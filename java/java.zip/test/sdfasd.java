package test;

import android.app.Fragment;
import android.app.FragmentController;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;

/**
 * @作者 做就行了！
 * @时间 2019/4/27 0027
 * @使用说明：
 */
public class sdfasd {
    ViewPager vp;
    Fragment f;

    public sdfasd() {
        f.setUserVisibleHint();
        vp.setAdapter(new PagerAdapter() {
            @Override
            public int getCount() {
                return 0;
            }

            @Override
            public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
                return false;
            }

            @Override
            public Object instantiateItem(ViewGroup container, int position) {
                return super.instantiateItem(container, position);
            }

            @Override
            public Object instantiateItem(View container, int position) {
                return super.instantiateItem(container, position);
            }
        });
    }
}

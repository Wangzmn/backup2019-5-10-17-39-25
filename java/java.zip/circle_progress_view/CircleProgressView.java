package circle_progress_view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Log;
import android.view.View;

import wclass.android.ui.draw.PaintUT;
import wclass.android.util.RectUT;
import wclass.android.util.SizeUT;
import wclass.util.MathUT;

/**
 * @作者 做就行了！
 * @时间 2019-04-04下午 10:42
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class CircleProgressView extends View {
    private static final boolean DEBUG = true;
    /**
     * 标记是否需要绘制。
     */
    private boolean needDraw;
    /**
     * todo
     * 1、圆心。
     * 2、半径。
     * 3、描边宽度。
     * 4、offsetDegree。
     */
    /**
     * step 麻烦事：
     * 1、不知道view的大小，
     * 用户根本没办法设置圆的各种信息。
     */
    /**
     * @param context
     */
    public CircleProgressView(Context context) {
        super(context);
        paint = onCreatePaint();

        if (DEBUG) {
            int mm = SizeUT.getMMpixel(context);
            trackBgWidth = mm;
            trackProgressWidth = 4 * mm;
            trackBgColor = 0xffaaaaaa;
            trackProgressColor = 0xff75f834;
        }
    }

    /**
     * view的可见区域。
     * <p>
     * 1、该属性是通过该方法获取的：
     * {@link View#getDrawingRect(android.graphics.Rect)}
     */
    Rect visualRect = new Rect();

    /**
     * view的绘制区域。
     * <p>
     * 无padding的{@link #visualRect}。
     */
    Rect drawRect = new Rect();

    /**
     * 获取view的可见区域。
     */
    public Rect getVisualRect() {
        return visualRect;
    }

    /**
     * 获取view的绘制区域。
     */
    public Rect getDrawRect() {
        return drawRect;
    }
    //////////////////////////////////////////////////
    /**
     * 补偿角度。
     * <p>
     * 友情提示：从X轴正方向，顺时针开始算。
     * <p>
     * 这里的默认值为往回90度，也就是Y轴正方向。
     */
    int offsetDegree = -90;
    /**
     * 进度轨道的背景颜色宽度。
     */
    int trackBgWidth = -1;
    /**
     * 进度的宽度。
     */
    int trackProgressWidth = -1;
    /**
     * 进度轨道的颜色。
     */
    int trackBgColor = 0xffaaaaaa;
    /**
     * 进度的颜色。
     */
    int trackProgressColor = 0xff75f834;
    /**
     * 圆心坐标。
     * 0下标：x坐标。
     * 1下标：y坐标。
     */
    float[] coreXY = new float[2];
    RectF circleRect = new RectF();

    //////////////////////////////////////////////////
    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            getDrawingRect(visualRect);
            RectUT.delPadding(visualRect, this, drawRect);
        }
        if (drawRect.isEmpty()) {
            needDraw = false;
            return;
        }
        preReCircle(changed);
        onAdjustCircleCoreXY(coreXY);
        radius = onReRadius();
        float coreX = coreXY[0];
        float coreY = coreXY[1];
        circleRect.left = coreX - radius;
        circleRect.top = coreY - radius;
        circleRect.right = coreX + radius;
        circleRect.bottom = coreY + radius;
        if (DEBUG) {
            Log.e("TAG", " onLayout ");
        }
    }

    /**
     * 圆的半径。
     */
    float radius;

    /**
     * 该方法中调整圆的半径。
     *
     * @return 圆的半径。
     */
    protected float onReRadius() {
        int strokeWidth = Math.max(trackBgWidth, trackProgressWidth);
        return RectUT.min(drawRect) / 2f - strokeWidth/2f;
    }

    /**
     * 调整圆之前，该方法会被调用。
     *
     * @param changed 布局是否改变过。
     *                true：布局改变过。
     *                false：布局未改变过。
     */
    protected void preReCircle(boolean changed) {

    }

    /**
     * 调整圆心坐标。
     *
     * @param coreXY 圆心坐标。
     *               {@link #coreXY}
     */
    protected void onAdjustCircleCoreXY(float[] coreXY) {
        Rect drawRect = getDrawRect();
        RectUT.getCore(drawRect, coreXY);
    }

    //////////////////////////////////////////////////
    float mProgress;

    public void setProgress(float progress) {
        progress = MathUT.limitFloat(progress, 0, 1);
        if (progress == mProgress) {
            return;
        }
        this.mProgress = progress;
        invalidate();
    }

    public float getProgress() {
        return mProgress;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (DEBUG) {
            Log.e("TAG", " onDraw ");
        }
        super.onDraw(canvas);
        preDrawCircleProgress(canvas);
        onDrawCircleProgress(canvas);
        //--------------------------------------------------
        /*画进度轨道。*/
        paint.setStrokeWidth(trackBgWidth);
        paint.setColor(trackBgColor);
        canvas.drawCircle(coreXY[0], coreXY[1], radius, paint);
        //--------------------------------------------------
        /*画进度。*/
        progressPath.rewind();
        paint.setStrokeWidth(trackProgressWidth);
        paint.setColor(trackProgressColor);
        progressPath.moveTo(coreXY[0], coreXY[1]);
        float sweepDegree = mProgress * 360;
        if(sweepDegree == 360){
            sweepDegree = 359;
        }
        progressPath.arcTo(circleRect, offsetDegree, sweepDegree,true);
        canvas.drawPath(progressPath, paint);
    }

    /**
     * 正式绘制圆。
     */
    protected void onDrawCircleProgress(Canvas canvas) {
    }

    /**
     * 绘制圆之前，该方法会被调用。
     */
    protected void preDrawCircleProgress(Canvas canvas) {

    }


    //////////////////////////////////////////////////
    Paint paint;
    Path progressPath = new Path();

    protected Paint onCreatePaint() {
        Paint paint = PaintUT.strokePaint();
        paint.setStrokeCap(Paint.Cap.ROUND);
        return paint;
    }
}

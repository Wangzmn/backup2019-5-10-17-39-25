package product.circle_shadow_drawable;

import wclass.android.ui.drawable.useful.ShadowDrawable;
import wclass.util.ColorUT;

/**
 * @作者 做就行了！
 * @时间 2019-03-30下午 11:00
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class RedShadowCircle extends ShadowDrawable {
    public RedShadowCircle() {
        super(COLOR);
    }

    private static final int COLOR = ColorUT.RED;
}

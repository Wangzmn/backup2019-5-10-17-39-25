package product.circle_shadow_drawable;

import wclass.android.ui.drawable.useful.ShadowDrawable;

/**
 * @作者 做就行了！
 * @时间 2019-03-30下午 11:00
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class YellowShadowCircle extends ShadowDrawable {
    public YellowShadowCircle() {
        super(COLOR);
    }

    private static final int COLOR = 0xffffff00;
}

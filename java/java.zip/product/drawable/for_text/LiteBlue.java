package product.drawable.for_text;

import wclass.android.ui.drawable.ColorWithStrokesDrawable;

/**
 * @作者 做就行了！
 * @时间 2019/3/30 0030
 * @使用说明：
 */
public class LiteBlue extends ColorWithStrokesDrawable {
    public LiteBlue() {
        super(0xff9da9f2,
                1/8f,
                0xffbbbbbb,1,0xfff6f6f6,2,0xff909090,2);
    }
}

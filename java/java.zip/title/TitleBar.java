//package title;
//
//import android.content.Context;
//import android.view.Gravity;
//import android.view.ViewGroup;
//import android.widget.FrameLayout;
//import android.widget.LinearLayout;
//
//import wclass.android.util.LayoutParamsUT;
//
///**
// * @作者 做就行了！
// * @时间 2019-04-17下午 5:54
// * @该类描述： -
// * @名词解释： -
// * @该类用途： -
// * @注意事项： -
// * @使用说明： -
// * @思维逻辑： -
// * @优化记录： -
// * @待解决： -
// */
//public class TitleBar extends FrameLayout {
//    LinearLayout main;
//
//    /**
//     * 待解决：
//     * 1、root大小改变时，重新调整所有子控件。
//     *
//     *
//     * 2、
//     *
//     */
//    public TitleBar(Context context) {
//        super(context);
//        ViewGroup.LayoutParams p =  LayoutParamsUT.makeWrapperContent();
//        setLayoutParams(p);//包裹LinearLayout。
//        //////////////////////////////////////////////////
//        ViewGroup.LayoutParams params = LayoutParamsUT.makeMatchParent();
//        ViewGroup.LayoutParams p = main.getLayoutParams();
//        p.width = ViewGroup.LayoutParams.MATCH_PARENT;
//        FrameLayout.LayoutParams pp;
//        if(p instanceof MarginLayoutParams){
//            MarginLayoutParams p1 = (MarginLayoutParams) p;
//            pp =  new FrameLayout.LayoutParams(p1);
//        }else{
//            pp = new FrameLayout.LayoutParams(p);
//        }
//        pp.gravity = Gravity.CENTER;
//        main.setLayoutParams(pp);
//    }
//
//
//}

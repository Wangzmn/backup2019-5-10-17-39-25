package drawable;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.support.annotation.NonNull;

import wclass.android.ui.draw.PaintUT;
import wclass.android.ui.draw.PathUT;
import wclass.android.ui.drawable.z_secondary.DrawableImpl;

/**
 * @作者 做就行了！
 * @时间 2019/4/19 0019
 * @使用说明：
 */
public class TestCustomCircleCornerRect extends DrawableImpl {
    RectF rect = new RectF();
    Path path = new Path();

    @Override
    public void draw(@NonNull Canvas canvas) {
        getLeftSquare(rect);
        int strokeWidth = 6;
        PathUT.makeCircleCornerRect(width, height, width / 2f,
                strokeWidth, path, 0, 0);
        paint.setColor(0xffff0000);
        paint.setStrokeWidth(strokeWidth);
//        paint.setStrokeJoin(Paint.Join.MITER);
        canvas.drawPath(path,paint);

    }

    @Override
    protected Paint onCreatePaint() {
        return PaintUT.strokePaint();
    }
}

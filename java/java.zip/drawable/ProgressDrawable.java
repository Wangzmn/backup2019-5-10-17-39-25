package drawable;

import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;

import wclass.android.ui.drawable.z_secondary.DrawableImpl;
import wclass.util.CircleUT;

/**
 * @作者 做就行了！
 * @时间 2019-04-18下午 11:31
 * @该类描述： -
 * 1、横向进度条，满进度时两端都是圆角。
 * 未满进度时：开始端是圆角，进度端为直角。
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class ProgressDrawable extends DrawableImpl {
    float progress;
    private boolean freak;

    public ProgressDrawable() {
    }

    Path path = new Path();

    RectF backup = new RectF();

    @Override
    public void draw(Canvas canvas) {
        if (freak) {
            return;
        }
        float progressValue = width * progress;
        float radius = (float) height / 2;

        //在头端圆角区域，不足圆角。
        if (progressValue < radius) {
            /**
             * 解释：
             * 0、三角形位于y轴正方向的左边，圆心作为三角形的锐角。
             * 1、y轴正方向为三角形的邻边直角边。
             * 2、该变量为三角形的对边直角边。
             * 3、圆的半径为三角形的斜边。
             */
            float triangleOpposite = radius - progressValue;
            double arc = Math.asin(triangleOpposite / radius);
            //y轴上方的左边的三角形，y轴上方与斜边的夹角。
            int degree = CircleUT.toDegree(arc);
            /**
             * 180：x轴负方向。
             * 90-degree：互补的角度。
             */
            int anotherDegree = 90 - degree;
            int startDegree = 180 - anotherDegree;
            path.rewind();
            path.moveTo(bounds.left + radius, bounds.top + radius);

            getLeftSquare(backup);
            path.arcTo(backup, startDegree, anotherDegree*2,
                    true);
            path.close();
        }

        //在尾端圆角区域，不足圆角。
        else if (progressValue > width - radius) {
            path.rewind();
            path.moveTo(bounds.left + radius, bounds.top + radius);
            getLeftSquare(backup);
            path.arcTo(backup,90,180,true);
            /**
             * 解释：
             * 0、三角形位于y轴正方向的右边，圆心作为三角形的锐角。
             * 1、y轴正方向为三角形的邻边直角边。
             * 2、该变量为三角形的对边直角边。
             * 3、圆的半径为三角形的斜边。
             * 4、你懂了吧。
             */
            float triangleHeight = progressValue - (width - radius);
            /**
             * y轴正方向右边的三角形，三角形的斜边 与 y轴正方向的夹角的弧度。
             */
            double arc = Math.asin(triangleHeight / radius);
            int degree = CircleUT.toDegree(arc);

//            path.rewind();
            getRightSquare(backup);
            path.moveTo(backup.left + radius, backup.top + radius);
            int startDegree_Top = 270;
            path.arcTo(backup,startDegree_Top,degree,true);
            //--------------------------------------------------
            int startDegree_Bottom = 90 - degree;
            path.arcTo(backup,startDegree_Bottom,degree,true);
            path.close();
        }

        //在中间区域。
        else {

        }


    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        if (height > width) {
            freak = true;
            return;
        }
    }
}

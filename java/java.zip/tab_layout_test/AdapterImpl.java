package tab_layout_test;

import android.content.Context;
import android.widget.ImageView;

import wclass.android.ui.view.tab_layout.TabLayoutImpl;
import wclass.common.WH;
import wclass.android.util.DebugUT;
import wclass.android.util.SizeUT;

/**
 * @作者 做就行了！
 * @时间 2019/4/23 0023
 * @使用说明：
 */
public class AdapterImpl extends TabLayoutImpl.AdapterII<ImageView> {

    private int tabCount = 5;
    private int gap;
    private int indicatorHolderSize = 10;

    @Override
    public int getIndicatorHolderSize() {
        return indicatorHolderSize;
    }

    int tabW, tabH;

    @Override
    public void onSizeChangedSafely(int w, int h) {
        gap = tabW = w / (tabCount * 2 - 1);
        int mm = SizeUT.getMMpixel(getContext());
        if (mm > h) {
            indicatorHolderSize = 1;
        } else {
            indicatorHolderSize = mm;
        }
        tabH = h - indicatorHolderSize;
    }

    @Override
    public void onSelectedTab(ImageView imageView, int dex) {

    }

    @Override
    public int getTabCount() {
        return tabCount;
    }

    @Override
    public ImageView onCreateTabView(int dex, Context context) {
        ImageView imageView = new ImageView(context);
        DebugUT.randomBG(imageView);
        return imageView;
    }

    @Override
    public int getSpaceBefore(int dex) {
        if(dex!=0){
            return tabW;
        }
        return 0;
    }

    @Override
    public WH getTabWH() {
        return new WH(tabW,tabH);
    }
}

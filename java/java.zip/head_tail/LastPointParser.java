package head_tail;


import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.List;

import wclass.android.ui.EventTypeConverter;
import wclass.enums.EventType;
import wclass.ui.event_pointer.PointerCodes;

/**
 * @作者 做就行了！
 * @时间 2019-04-14下午 4:44
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class LastPointParser extends PointerCodes<LastPointParser> {
    private int lastID;

    public LastPointParser(int worm) {
        super(worm);
    }

    public LastPointParser(int worm, float perH, float perV) {
        super(worm, perH, perV);
    }

    private int getDexById(MotionEvent ev, int id) {
        for (int i = 0; i < ev.getPointerCount(); i++) {
            int pointerId = ev.getPointerId(i);
            if (pointerId == id) {
                return i;
            }
        }
        return -1;
    }

    List<Integer> ids = new ArrayList<>();

    //    public void parse(EventType type,)
    public void parse(MotionEvent ev) {
        int actionMasked = ev.getActionMasked();
        EventType type = EventTypeConverter.convert(actionMasked);
//        int acdex = ev.getActionIndex();
//        int ptid = ev.getPointerId(acdex);

        switch (type) {
            /**
             * 1、记录点的id。
             * 2、重置点的坐标。
             * 3、并且记录最后一个点id，方便MOVE中通过id获取坐标。
             */
            case DOWN:
                /**
                 * 次点落下时，重新记录按下时、旧move的坐标。
                 */
            case POINTER_DOWN:
                onDown(ev);
                break;
            //--------------------------------------------------
            case MOVE:
                int dex = getDexById(ev, lastID);
                if (dex == -1) {
                    //最后一个id居然没有下标，不应该吧。
                    return;
                }
                onMoveEvent(ev.getX(dex), ev.getY(dex));
                break;
            /**
             * 1、删除指定id，如果是最后一个点，那么找倒数第二个点。
             */
            case POINTER_UP:
                updateLastID(ev);
                break;
            case UP:
                break;
            case NO_POINTER:
                break;
            case EXIT_WITH_NO_POINTER:
                break;
        }

    }

    private void updateLastID(MotionEvent ev) {
        int acdex = ev.getActionIndex();
        int ptid = ev.getPointerId(acdex);
        if (ptid == lastID) {
            //todo 从集合类中删除。
            //todo 之后，集合类最后一个id设置为lastID。
        }
    }

    private void onDown(MotionEvent ev) {
        int acdex = ev.getActionIndex();
        int ptid = ev.getPointerId(acdex);
        lastID = ptid;
        //todo 集合类中添加此id。
        onDownEvent(ev.getX(acdex), ev.getY(acdex));
    }

}

package head_tail;

import android.view.MotionEvent;

/**
 * @作者 做就行了！
 * @时间 2019/4/14 0014
 * @使用说明：
 */
public interface Callback {
    /**
     * 1、用getXY，只有最后一个按下的点才有滑动距离。
     */
    /**
     *
     * @return
     */
    State getState();

    void onHeadGoing(float delta);
    void onHeadBacking(float delta);
    void onHeadUp();
    void onTailGoing(float delta);
    void onTailBacking(float delta);
    void onTailUp();

    enum State {
        HEAD_GOING,
        TAIL_GOING,
        NORMAL
    }
}

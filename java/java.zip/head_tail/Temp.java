package head_tail;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

/**
 * @作者 做就行了！
 * @时间 2019-04-13下午 11:45
 * @该类描述： -
 * @名词解释： -
 * @该类用途： -
 * @注意事项： -
 * @使用说明： -
 * @思维逻辑： -
 * @优化记录： -
 * @待解决： -
 */
public class Temp {
    RecyclerView r;
    View v;

    public Temp(RecyclerView r, View v) {
        this.r = r;
        this.v = v;
//        v.canScrollVertically();

//        r.scroll
        r.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });
        class l extends LinearLayout{

            public l(Context context) {
                super(context);
            }

            @Override
            protected void onFinishInflate() {
                super.onFinishInflate();
            }
        }
    }
}
